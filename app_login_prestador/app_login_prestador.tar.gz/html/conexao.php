<?php
define('HOST', '172.17.0.12');
define('USUARIO', 'root');
define('SENHA', 'matrix123');
define('DB', 'loginPrestador');

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');
