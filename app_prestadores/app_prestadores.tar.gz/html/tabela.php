<?php
include "db.php";

// Mostra os prestadores
$selectPrestadores = "SELECT * FROM prestadores";
$queryPrestadores = $connection->query($selectPrestadores);

function exibirPrestadores(){
    global $queryPrestadores;
    if ($queryPrestadores->num_rows > 0){
        echo "
            <table>
            <tr>
            <th>Nome</th>
            <th>Serviço</th>
            <th>Valor por Hora (R$)</th>
            </tr>
            ";
        while($row = $queryPrestadores->fetch_assoc()){
            echo "<tr>";
            echo "<td>" . "<input type='text' class='$row[id]' value='$row[nome]'>" . "</td>";
            echo "<td>" . "<input type='text' class='$row[id]' value='$row[servico]'>" . "</td>";
            echo "<td>" . "<input type='text' class='$row[id]' value='$row[valor_hora]'>" . "</td>";
            echo "<td>" . "<input type='submit' onclick='atualizarDados($row[id])' value='Salvar alterações'>" . "</td>";
            echo "<td>" . "<input type='submit' onclick='apagarDados($row[id])' value='Apagar'>" . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else{
        echo "<p>Sem prestadores cadastrados</p>";
    }
}

$connection->close();
?>
