<?php
include "db.php";

// Adicionar as informações do prestador no banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $nome = $_POST["nome"];
    $servico = $_POST["servico"];
    $valor_hora = $_POST["valor_hora"];
    $insertDados = "INSERT INTO prestadores(nome, servico, valor_hora) VALUES ('$nome', '$servico', '$valor_hora')";
    $connection->query($insertDados);
}

$url = "index.php";

header('Location: '.$url);

$connection->close();
?>
