<?php
include "db.php";

// Atualiza os produtos
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])){
    $id = $_POST["id"];
    $nome = $_POST["nome"];
    $servico = $_POST["servico"];
    $valor_hora = $_POST["valor_hora"];
    $updateDados = "UPDATE prestadores SET nome='$nome', servico='$servico', valor_hora='$valor_hora' WHERE id=$id";
    $connection->query($updateDados);
}

$connection->close();
?>
