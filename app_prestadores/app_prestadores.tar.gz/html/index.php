<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Sistema de cadastro de produtos</title>
</head>
<body>
    <h1>Sistema de cadastro de prestadores de Serviços</h1>
<div style="text-align: center">
<a href="http://192.168.0.31:1010" class="btn btn-success">Logout</a>
</div>
    <form action="cadastro.php" method="post">
        <label>Nome do prestador:</label>
        <input type="text" name="nome">

        <label>Serviço:</label>
        <input type="text" min="0" name="servico">

        <label>Valor por Hora:</label>
        <input type="number" min="0" name="valor_hora">

        <input type="submit" value="Cadastrar prestador">
    </form>
    <p>Prestadores e Serviços Cadastrados:</p>
    <?php
    include "tabela.php";
    exibirPrestadores();
    ?>

    <script>
        function atualizarDados(id){
            let classValor = document.getElementsByClassName(id);
            let nome = classValor[0].value;
            let servico = classValor[1].value;
            let valor_hora = classValor[2].value;

            const xhttp = new XMLHttpRequest();
            xhttp.open("POST", "update.php");
            xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhttp.send("id=" + id + "&nome=" + nome + "&servico=" + servico + "&valor_hora=" + valor_hora);
        }
    
        function apagarDados(id){
            const xh = new XMLHttpRequest();
            xh.open("POST", "delete.php");
            xh.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xh.send("id=" + id);
            xh.onload = function() {
                if (xh.status == 200) {
                    location.reload();
                }
                }
        }
    </script>
</body>
</html>
