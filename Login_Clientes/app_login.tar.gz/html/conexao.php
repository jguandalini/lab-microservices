<?php
define('HOST', '172.17.0.3');
define('USUARIO', 'root');
define('SENHA', 'matrix123');
define('DB', 'login');

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');
