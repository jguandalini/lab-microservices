<?php
include "db.php";

// Atualiza as empresas e serviços 
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])){
    $id = $_POST["id"];
    $nome_empresa = $_POST["nome_empresa"];
    $servico = $_POST["servico"];
    $valor_hora = $_POST["valor_hora"];
    $updateDados = "UPDATE empresas SET nome_empresa='$nome_empresa', servico='$servico', valor_hora='$valor_hora' WHERE id=$id";
    $connection->query($updateDados);
}

$connection->close();
?>
