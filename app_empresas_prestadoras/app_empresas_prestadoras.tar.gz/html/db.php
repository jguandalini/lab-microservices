<?php

// Informações de login
$servername = "172.17.0.8";
$username = "root";
$password = "matrix123";
$dbname = "cadastroEmpresas";

// Conexão com o banco de dados
$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error){
    die($connection->connect_error);
}

?>

