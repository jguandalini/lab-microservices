<?php
include "db.php";

// Adicionar as informações do prestador no banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $nome_empresa = $_POST["nome_empresa"];
    $servico = $_POST["servico"];
    $valor_hora = $_POST["valor_hora"];
    $insertDados = "INSERT INTO empresas(nome_empresa, servico, valor_hora) VALUES ('$nome_empresa', '$servico', '$valor_hora')";
    $connection->query($insertDados);
}

$url = "index.php";

header('Location: '.$url);

$connection->close();
?>

