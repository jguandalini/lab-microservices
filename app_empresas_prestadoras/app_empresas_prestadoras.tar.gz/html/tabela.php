<?php
include "db.php";

// Mostra as empresas prestadoras
$selectEmpresas = "SELECT * FROM empresas";
$queryEmpresas = $connection->query($selectEmpresas);

function exibirEmpresas(){
    global $queryEmpresas;
    if ($queryEmpresas->num_rows > 0){
        echo "
            <table>
            <tr>
            <th>Nome da Empresa Prestadora</th>
            <th>Serviço</th>
            <th>Valor por Hora (R$)</th>
            </tr>
            ";
        while($row = $queryEmpresas->fetch_assoc()){
            echo "<tr>";
            echo "<td>" . "<input type='text' class='$row[id]' value='$row[nome_empresa]'>" . "</td>";
            echo "<td>" . "<input type='text' class='$row[id]' value='$row[servico]'>" . "</td>";
            echo "<td>" . "<input type='text' class='$row[id]' value='$row[valor_hora]'>" . "</td>";
            echo "<td>" . "<input type='submit' onclick='atualizarDados($row[id])' value='Salvar alterações'>" . "</td>";
            echo "<td>" . "<input type='submit' onclick='apagarDados($row[id])' value='Apagar'>" . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else{
        echo "<p>Sem empresas prestadoras cadastradas</p>";
    }
}

$connection->close();
?>
